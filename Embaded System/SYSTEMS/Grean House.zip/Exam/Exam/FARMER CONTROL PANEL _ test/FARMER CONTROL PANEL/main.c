#include <avr/io.h>
#include <stdint.h>
#include <util/delay.h>

#include "UART.h"
#include "SPI.h"
#include "I2C.h"

/* =========================================================
   DIP Switch
   ========================================================= */

#define DIP_MASK       0x0F

/*
 * Temperature = DIP + 15
 *
 * DIP = 0000 -> 15 C
 * DIP = 0001 -> 16 C
 * DIP = 0101 -> 20 C
 * DIP = 1010 -> 25 C
 * DIP = 1111 -> 30 C
 */


/* =========================================================
   Buttons
   ========================================================= */

#define B1_PIN         PD2
#define B2_PIN         PD3
#define increase_temp	20

/* =========================================================
   SPI
   ========================================================= */

#define SPI_START      0xAA


/* =========================================================
   DIP Initialization
   ========================================================= */

void DIP_Init(void)
{
    /*
     * PC0-PC3 = INPUT
     */

    DDRC &= ~(1 << PC0);
    DDRC &= ~(1 << PC1);
    DDRC &= ~(1 << PC2);
    DDRC &= ~(1 << PC3);


    /*
     * Internal Pull-ups
     */

    PORTC |= (1 << PC0);
    PORTC |= (1 << PC1);
    PORTC |= (1 << PC2);
    PORTC |= (1 << PC3);
}


/* =========================================================
   Read DIP
   ========================================================= */
// send dip 
//read
// increase 
// send to mcu b
uint8_t DIP_Read(void)
{
    /*
     * Hardware:
     *
     * Switch ON  = PIN 0
     * Switch OFF = PIN 1
     *
     * Convert:
     *
     * ON  = 1
     * OFF = 0
     */

    return ((~PINC) & DIP_MASK);
}


/* =========================================================
   Convert DIP to Temperature
   ========================================================= */

uint8_t DIP_To_Temperature(void)
{
	u8 read_dip=DIP_Read();
	//7
	return read_dip + increase_temp;
	//20 =>increase
	//read ==7
	//27
}


/* =========================================================
   Buttons Initialization
   ========================================================= */

void Buttons_Init(void)
{
    /*
     * B1 = PD2
     * B2 = PD3
     */

    DDRD &= ~(1 << B1_PIN);
    DDRD &= ~(1 << B2_PIN);


    /*
     * Internal Pull-ups
     */

    PORTD |= (1 << B1_PIN);
    PORTD |= (1 << B2_PIN);
}


/* =========================================================
   Read B1
   ========================================================= */

uint8_t B1_Read(void)
{
    /*
     * Released = 1
     * Pressed  = 0
     */

    return ((PIND >> B1_PIN) & 1);
}


/* =========================================================
   Read B2
   ========================================================= */

uint8_t B2_Read(void)
{
    /*
     * Released = 1
     * Pressed  = 0
     */

    return ((PIND >> B2_PIN) & 1);
}


/* =========================================================
   Send SETMIN
   ========================================================= */

void Send_SetMin(u8 temp )
{
	u8 read_b1= B1_Read();
	if (read_b1==0)
	{
		//UART_SendString("SETMIN");
		UART_SendChar('M');
		_delay_ms(5);          
		SPI_Send_Panel(temp);
		while (B1_Read() == 0); 
	}	
    
}


/* =========================================================
   Send SETMAX
   ========================================================= */

void Send_SetMax(u8 temp)
{
   u8 read_b2= B2_Read();
   if (read_b2==0)
   {
	  // UART_SendString("SETMAX");
	  UART_SendChar('X');
	  _delay_ms(5);        
	   SPI_Send_Panel(temp);
	   while (B2_Read() == 0); 
   }
}



void SPI_Send_Panel(u8 data)
{
    SPI_u8Transceive(data);
}


/* =========================================================
   MAIN
   ========================================================= */

int main(void)
{
    UART_Init(9600);
	SPI_voidMaster_Init();
	DIP_Init();
    Buttons_Init();
	
    while (1)
    {
        /* =================================================
           Read Buttons
           ================================================= */


        /* =================================================
           Read Temperature From DIP
           ================================================= */

        DIP_Read();
		B1_Read();
		B2_Read();
		u8 data=DIP_To_Temperature();
		Send_SetMin(data);
		Send_SetMax(data);
        
	}

    return 0;
}