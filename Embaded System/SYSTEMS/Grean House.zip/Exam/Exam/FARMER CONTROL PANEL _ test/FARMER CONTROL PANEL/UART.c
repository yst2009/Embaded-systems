
#include <avr/io.h>
#include "uart.h"

#define F_CPU 1000000UL
#include <util/delay.h>

void UART_Init(uint16_t baudrate)
{
UBRR0H = (unsigned char)(baudrate>>8);
UBRR0L = (unsigned char)baudrate;
UCSR0B = (1<<RXEN0)|(1<<TXEN0);
UCSR0C = (1<<UCSZ00)|(1<<UCSZ01);
}


void UART_SendChar(char data)
{
while (!(UCSR0A & (1<<UDRE0)));
	UDR0 = data;
}

void UART_SendString(const char *str)
{
	uint8_t index=0;
	while (str[index]!='\0')
	{
		UART_SendChar(str[index++]);
	}
}

char UART_ReceiveChar(void)
{
	while (!(UCSR0A & (1<<RXC0)))
	;
	return UDR0;
}
void UART_SendHex(uint8_t data)
{
	const char hex[] = "0123456789ABCDEF";

	UART_SendChar(hex[(data >> 4) & 0x0F]);
	UART_SendChar(hex[data & 0x0F]);
}
void UART_ReceiveString(char *str, uint8_t max_size)
{
	uint8_t index = 0;
	char c;

	while (index < (max_size - 1))
	{
		c = UART_ReceiveChar();

		if (c == '\r' || c == '\n')
		{
			break;
		}

		str[index++] = c;
	}

	str[index] = '\0';
}
uint8_t UART_DataAvailable(void)
{
	return (UCSR0A & (1 << RXC0));
}

