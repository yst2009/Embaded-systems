
#define  F_CPU  16000000UL
#include <avr/io.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <util/delay.h>
#include "BIT_MATH.h"
#include "I2C.h"
#include "LCD.h"
#include "LM75.h"
#include "EEPROM.h"
#include "UART.h"
#include "SPI.h"
#include "UART.h"
//LM75A       = 0x48
//EEPROM      = 0x50
//PCF8574     = 0x40

#define HEATER_PIN          PB1
#define FAN_PIN             PB0

#define WARNING_LED_PIN     PD4
#define BUZZER_PIN          PD5

#define EEPROM_MIN_ADDR     0x0000
#define EEPROM_MAX_ADDR     0x0001
#define EEPROM_MAGIC_ADDR   0x0002

#define EEPROM_MAGIC        0xA5



#define DEFAULT_MIN_TEMP    18
#define DEFAULT_MAX_TEMP    28

#define HYSTERESIS          1
#define HIGH_TEMP           35





uint8_t sensor_error_count = 0;
uint8_t high_temp_warning = 0;

uint8_t panel_dip = 0;
uint8_t panel_b1 = 1;
uint8_t panel_b2 = 1;

uint8_t min_temp=20;
uint8_t max_temp=30;
u8 data;
u8 bad_current;
void EEPROM_init(){
	EEPROM_Write(EEPROM_MIN_ADDR,min_temp);
	EEPROM_Write(EEPROM_MAX_ADDR,max_temp);
	bad_current=0;
	EEPROM_Write(EEPROM_MAGIC_ADDR,bad_current);
}

void Read_Temperature()
{
		bad_current=EEPROM_Read(EEPROM_MAGIC_ADDR);
		while (LM75_ReadTemperature()==0);
    		data=LM75_ReadTemperature();
    		if (bad_current<3)
    		{
	    		if(data < min_temp){
					PORTD &= ~((1 << WARNING_LED_PIN) | (1 << BUZZER_PIN));
		    		PORTB|=(1<<HEATER_PIN);
		    		PORTB&=~(1<<FAN_PIN);
											LCD_SetCursor(0,0);
											LCD_String("Temp: ");
											LCD_SetCursor(0,5);
											LCD_Number(data);
										bad_current++;
										EEPROM_Write(EEPROM_MAGIC_ADDR,bad_current);
						
					
	    		}
	    		else if(data> max_temp){
					PORTD &= ~((1 << WARNING_LED_PIN) | (1 << BUZZER_PIN));
		    		PORTB|=(1<<FAN_PIN);
		    		PORTB&=~(1<<HEATER_PIN);
											LCD_SetCursor(0,0);
											LCD_String("Temp: ");
											LCD_SetCursor(0,5);
											LCD_Number(data);
					bad_current++;
					EEPROM_Write(EEPROM_MAGIC_ADDR,bad_current);

	    		}
	    		
	    		else{
		    		PORTB&=~(1<<1);
		    		PORTB&=~(1<<0);
					PORTD &= ~((1 << WARNING_LED_PIN) | (1 << BUZZER_PIN));
											LCD_SetCursor(0,0);
											LCD_String("Temp: ");
											LCD_SetCursor(0,5);
											LCD_Number(data);
											
	    		}
	    			
					_delay_ms(500);
	    	}else {
				
				PORTD|=(1<<WARNING_LED_PIN);
				PORTD|=(1<<BUZZER_PIN);
				PORTB&=~(1<<HEATER_PIN);
				PORTB&=~(1<<FAN_PIN);
				EEPROM_Write(EEPROM_MAGIC_ADDR,0);
								LCD_SetCursor(0,0);
								LCD_String("Warning");
								bad_current=0;
				_delay_ms(1000);
			}
	  
}

/* =========================================================
   MAIN
   ========================================================= */

int main(void)
{
	SET_BIT(DDRB,HEATER_PIN);
	SET_BIT(DDRB,FAN_PIN);
	SET_BIT(DDRD,WARNING_LED_PIN);
	SET_BIT(DDRD,BUZZER_PIN);
		UART_Init(9600);
		SPI_voidSlave_Init();
		I2C_Master_Init();
		LCD_Init();
		
		EEPROM_init();
    while (1)
    {
		Read_Temperature();
		if (UART_DataAvailable())
		{
		
		u8 ch = UART_ReceiveChar();
		if (ch=='X')
		{
			max_temp=SPI_u8Receive();
						EEPROM_Write(EEPROM_MAX_ADDR,max_temp);
						LCD_Clear();
						LCD_SetCursor(0,0);
						LCD_String("Update Max");
		}
		else if(ch =='M'){
			min_temp=SPI_u8Receive();
						EEPROM_Write(EEPROM_MIN_ADDR,min_temp);
						LCD_Clear();
						LCD_SetCursor(0,0);
						LCD_String("Update Min");		
			}
		
		}
      _delay_ms(50);
	  LCD_Clear();

	}


    return 0;
}